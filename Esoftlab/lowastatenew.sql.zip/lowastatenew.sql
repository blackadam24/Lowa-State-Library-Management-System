-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2021 at 03:47 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lowastatenew`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `NIC` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Passcode` varchar(40) NOT NULL,
  `Fname` varchar(35) NOT NULL,
  `Lname` varchar(35) NOT NULL,
  `Mobile` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`NIC`, `Email`, `Passcode`, `Fname`, `Lname`, `Mobile`) VALUES
('992357382v', 'tony@gmail.com', 'tony123', 'Tony', 'Stark', '0763549821'),
('992518234v', 'nayana@gmail.com', 'nayana123', 'Nayanajith', 'Rambukwella', '0743217812'),
('992522134v', 'tharindu@gmail.com', 'tharindu123', 'Tharindu', 'Nuwantha', '0768954321'),
('993217241v', 'john@gmail.com', 'John123', 'John', 'Chris', '0754321912'),
('993526123v', 'admin@gmail.com', 'admin123', 'Supun', 'Sampath', '0765840320');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `B_ID` int(24) NOT NULL,
  `Book_name` varchar(50) NOT NULL,
  `Author` varchar(50) NOT NULL,
  `Category` varchar(35) NOT NULL,
  `Quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`B_ID`, `Book_name`, `Author`, `Category`, `Quantity`) VALUES
(26, 'The rain', 'W. Martin', 'Novel', 16),
(27, 'Lord of the rings', 'J.J Talkin', 'Novel', 12),
(28, 'Halloween', 'Charles', 'Science Friction', 15),
(37, 'Madol duwa', 'J.K Rowlin', 'Novel', 15),
(42, 'Harry Potter', 'J.K Rowlin', 'Novel', 12),
(43, 'Mother', 'H.G Wells', 'Novel', 18),
(48, 'Rich dad and poor dad', 'R.Kiyosaki', 'Novel', 7);

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE `rent` (
  `B_ID` int(20) NOT NULL,
  `Book_name` varchar(60) NOT NULL,
  `NIC` varchar(20) NOT NULL,
  `Rent_Date` date NOT NULL,
  `Return_Date` date NOT NULL,
  `Fine` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`B_ID`, `Book_name`, `NIC`, `Rent_Date`, `Return_Date`, `Fine`) VALUES
(43, 'Mother', '928156215v', '2021-10-11', '2021-10-13', 500),
(26, 'The rain', '931426738v', '2021-11-01', '2021-11-03', 1000),
(29, 'Lord of the rings', '995647382v', '2021-10-14', '2021-10-16', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `NIC` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Passcode` varchar(30) NOT NULL,
  `Fname` varchar(35) NOT NULL,
  `Lname` varchar(35) NOT NULL,
  `Usertype` varchar(10) NOT NULL,
  `Mobile` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`NIC`, `Email`, `Passcode`, `Fname`, `Lname`, `Usertype`, `Mobile`) VALUES
('931426738v', 'viraj@gmail.com', 'viraj123', 'Sanjuka', 'Viraj', 'Student', '0758492134'),
('985411234v', 'isuru@gmail.com', 'isuru123', 'Isuru', 'Thiwankara', 'Proffessor', '0758942612'),
('991367549v', 'ceyloancooperation@gmail.com', 'cey123', 'Shan', 'Hansaja', 'Student', '0754328192'),
('992356217v', 'kamal@gmail.com', 'kamal123', 'Kamal', 'Anuradha', 'Student', '0762018361'),
('992360459v', 'user@gmail.com', 'user123', 'Sugith', 'Sithmal', 'Student', '0764578291'),
('9924121421v', 'user1@gmail.com', 'user123', 'Hasindu', 'Lakshan', 'Proffessor', '0762297231'),
('992451628v', 'use123@gmail.com', 'seu123', 'Thushel', 'Sanjana', 'Student', '0758493214'),
('9934152148', 'rashmi@gmail.com', 'rashmi123', 'Rashmi', 'Kanchana', 'Student', '0763718291'),
('993426231v', 'user3@gmail.com', 'users123', 'Namal', 'Anuradha', 'Student', '0760489459'),
('993427335v', 'wayblingo@gmail.com', 'way123', 'tommy', 'Stark', 'Proffessor', '0769620452'),
('993459915v', 'rob@gmail.com', 'rob123', 'Steve', 'Smith', 'Student', '0754788797'),
('9942536172v', 'hello@gmail.com', 'hello123', 'Roshith', 'Madhawa', 'Proffessor', '0705643281'),
('995647382v', 'nat@gmail.com', 'nat123', 'Robert', 'Downey', 'Proffessor', '0765443432'),
('999156215v', 'nav@gmail.com', 'nav123', 'Navod', 'Pasan', 'Student', '0765564511');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`NIC`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`B_ID`);

--
-- Indexes for table `rent`
--
ALTER TABLE `rent`
  ADD PRIMARY KEY (`NIC`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`NIC`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `B_ID` int(24) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
